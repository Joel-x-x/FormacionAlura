package com.alura.jdbc.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.alura.jdbc.factory.ConnectionFactory;

import java.util.HashMap;


import java.sql.Statement;

public class ProductoController {

	public int modificar(String nombre, String descripcion, Integer id) throws SQLException {
		Connection connection = new ConnectionFactory().creaConexion();
		
		PreparedStatement statement = connection.prepareStatement("update producto set nombre = ?, descripcion = ? where id = ?");
		statement.setString(1, nombre);
		statement.setString(2, descripcion);
		statement.setInt(3, id);
		
		statement.execute();
		
		int nItem = statement.getUpdateCount();
		
		connection.close();
		
		return nItem;
	}

	public int eliminar(Integer id) throws SQLException{
		Connection connection = new ConnectionFactory().creaConexion();
		
		PreparedStatement statement = connection.prepareStatement("delete from producto where id = ?");
		
		statement.setInt(1, id);
		
		statement.execute();
		
		int nItem = statement.getUpdateCount();
		
		connection.close();
		
		return nItem;
	}

	public List<Map<String, String>> listar() throws SQLException{
		
			Connection connection = new ConnectionFactory().creaConexion();
		
			PreparedStatement statement = connection.prepareStatement("select * from producto");
			
			statement.execute();
			
			ResultSet resultSet = statement.getResultSet();
			
			List<Map<String, String>> resultado = new ArrayList<>();
			
			while(resultSet.next()) {
				Map<String, String> fila = new HashMap<>();
				fila.put("id", String.valueOf(resultSet.getInt("id")));
				fila.put("nombre", resultSet.getString("nombre"));
				fila.put("descripcion", String.valueOf(resultSet.getString("descripcion")));
				fila.put("cantidad", String.valueOf(resultSet.getInt("cantidad")));
				
				resultado.add(fila);
			}
			
			connection.close();

		
		
		return resultado;
	}

    public void guardar(Map<String, String> producto)  throws SQLException{
    	String nombre = producto.get("nombre");
    	String descripcion = producto.get("descripcion");
    	Integer cantidad = Integer.valueOf(producto.get("cantidad"));
    	Integer maximoCantidad = 50;
    	
		Connection connection = new ConnectionFactory().creaConexion();
		
		PreparedStatement statement  = connection.prepareStatement("insert into producto(nombre, descripcion, cantidad)"
				+ "values(?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
		
		do {
			int cantidadGuardar = Math.min(cantidad, maximoCantidad);
			
			ejecutaRegistro(nombre, descripcion, cantidadGuardar, statement);

			
		} while();
		
		connection.close();
	}

	private void ejecutaRegistro(String nombre, String descripcion, Integer cantidad, PreparedStatement statement)
			throws SQLException {
		statement.setString(1, nombre);
		statement.setString(2, descripcion);
		statement.setInt(3, cantidad);
		
		statement.execute();
		
		ResultSet resultSet = statement.getGeneratedKeys();
		
		while(resultSet.next()) {
			System.out.println(String.format("Fue insertado el producto id %d", resultSet.getInt(1)));
		}
	}

}
